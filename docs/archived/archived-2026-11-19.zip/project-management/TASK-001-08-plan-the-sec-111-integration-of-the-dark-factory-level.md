# TASK-001.08: plan the sec-111 integration of the dark factory level

Part of TASK-001. The level designer delivers the dark factory as a level pair, a `.glb`
and a `.json`, and sec-111 cannot load that pair yet. This subtask assesses how sec-111
integrates the level and writes a reviewed integration plan for the owner. It builds
nothing: the owner sees the reviewed plan first, and the integration itself follows the
owner's decision on the plan.

## The owner's requirement

The owner wrote this on 2026-11-19, when TASK-001.07 was marked done. It is the
requirement.

```text
Once done, use your team to assess sec-111 integration. The technical direction is: keep
it simple and contain the complexity in the level-designer repo. However, do understand
that, the art direction wants to animated the light in gameplay and add more VFX to it,
therefore, the integration MUST NOT compromise these further visual development. It must
not make any assumption. If anything is unclear, you assess whether existing design doc
answers them; if not, raise as questions clearly and structurally. I expect to see the
reviewed integration plan first.
```

## Outcome

- An assessment of the sec-111 integration, grounded in the present state of sec-111, of
  the level pair and of the design documents.
- A reviewed integration plan that keeps the integration simple and contains its
  complexity in this repository.
- The plan leaves the further visual development open: lights animated in gameplay, and
  more VFX. It names each point where the integration could constrain that development,
  and how it avoids the constraint.
- The plan rests on no assumption: every premise names its evidence, a file of a
  repository or a design document.
- Every question that no design document answers is raised to the owner, clearly and in a
  structured form.
- The owner has seen the reviewed plan. No code of the integration is written before that.

## Task genesis

Components: this subtask changes none. The plan names the components of this repository
and the parts of sec-111 that the integration touches.

Read first:

- `TASK-001-deliver-the-dark-factory-level.md`, for the brief, the owner's decisions and
  the rules. Its decisions on adoption and its decisions of 2026-11-19 bind this subtask.
- `TASK-001-07-look-dev-the-dark-factory-with-procedural-materials.md`, for the state of
  the look development.
- In `docs/researches/2026-11-16-level-designer-foundation/`: `architecture.md`,
  `level-format.md` with "Lighting mapping rules" and "What sec-111 changes at adoption",
  and the research reports on the sec-111 level contract and on rendering and lighting.
- In `docs/researches/2026-11-17-dark-factory-look-dev/`: `design.md`, `finish-format.md`
  with "Mapping rules" and "What sec-111 changes at adoption",
  `non-destructible-objects.md` with "At adoption", and `painter-cost.md`.
- `docs/KNOWLEDGE.md` with its accepted limits, `docs/LOOK-AND-LIGHTING.md` and
  `docs/AUTHORING-GUIDE.md`.
- The knowledge documents of the three gateways and of `level-format`, `level-glb`,
  `finish-paint` and `level-view`.
- In `../sec-111`: its README, its knowledge documents and the source of what loads,
  prepares, simulates and draws a level, its lights and its VFX. In `../rendering-poc` and
  `../destruction-poc`: the documents and the source that the plan depends on. The three
  repositories are read-only.
- The three retros in `../skin-designer/docs/retros/`.

Research subjects:

- How sec-111 loads, prepares, simulates and draws its level today, and what each of those
  parts needs to take the level pair.
- How sec-111 lights its level and drives its VFX today, and what lights animated in
  gameplay and more VFX need from the level's data and from the integration.
- Where each part of the integration's complexity can live: in this repository or in
  sec-111.

Rules, from the owner's direction of 2026-11-19:

- Keep the integration simple, and contain its complexity in the level-designer
  repository.
- The art direction wants to animate the lights in gameplay and to add more VFX. The
  integration must not compromise that further visual development.
- Make no assumption. Where something is unclear, first assess whether an existing design
  document answers it. If none does, raise it to the owner as a question, clearly and in a
  structured form.
- The owner sees the reviewed integration plan first. Build nothing of the integration
  before the owner has decided on the plan.

Rule from the owner's answer of 2026-11-19, on what crosses into sec-111. The brief has
sec-111 consume the level data and never the designer's code, and a decision of 2026-11-18
allows sec-111 a copy of the generic painter files. The owner settled the two with this
sentence: "if the painter files are treated as immutable data, copy it; if they are code,
contain it."

- What crosses as immutable data is copied into sec-111 and never edited there.
- What is code stays contained in this repository, and sec-111 keeps no copy of it.
- The owner then chose the form, among a read-only snapshot of the sources, a live link and
  a copy of the painter alone: "Live link, no copy." The code that the game runs to read and
  draw the level exists only in this repository, and sec-111 imports it from this
  repository's working tree. For that code this replaces the brief's sentence that sec-111
  never consumes the designer's code.

The owner also stated on 2026-11-19 that sec-111 takes no more changes until the level
integration is settled, so the plan stands on sec-111 as it is. The integration therefore
blocks every other work, and the owner calls it mission critical.

Rules from the owner's answers of 2026-11-19 to the plan's four questions:

- sec-111 stays frozen until the whole integration is done. No other sec-111 work resumes
  at an earlier milestone.
- The team lead acts as sec-111's project manager and creates the integration's tasks in
  the sec-111 repository. Sessions of that repository execute them, so this team's sessions
  write no source into sec-111.
- The first integration reserves nothing for animated lights or more VFX. They cannot start
  before the integration is done, and they are outside its scope. The integration ensures
  that the code leaves room for them, and documents that room in the knowledge artifacts.
- A blown-open wide prop still blocks the movement of the player and of the enemies, and
  the player can shoot through it.

Rules from the owner's reminders of 2026-11-19, given while the plan was reviewed:

- No milestone of the plan is too large for the team: a healthy milestone holds a workload
  of at most 3,000 lines of code, and the review judges the distribution.
- The level design work is done, and the integration is strictly about integration. The
  level's `.glb` file and its `.json` file are immutable through the integration.
- Git ensures it, and nothing else does: the last commit that touches each level file is
  recorded, and no new commit touches those files. On 2026-11-19 the tracked level file of
  this repository is `levels/dark-factory.json`, last touched by commit `c495907`, and the
  base stage in sec-111 is `assets/stages/old_factory_free.glb`, last touched by commit
  `a68868f`. This repository tracks no `.glb`: the level pair is a build product.

Rules from the owner's further answers of 2026-11-19:

- Every standing prop keeps blocking the movement of the player and of the enemies after it
  is blown open, partitions included, and shots pass through what the damage has opened.
- The built pair is committed in sec-111, at the first import, and no later commit touches
  it there. This repository keeps tracking the description alone.
- The prepared level in sec-111's own schema is derived, and its two files may be committed
  again when sec-111's preparation changes. The immutability covers the level pair alone.
- The milestones clean up first: the level shows, props block and break, recording and
  replay, the six-wall level goes, minions navigate, finishes survive damage.
- The rules for everyone on TASK-001 apply: the sibling repositories are read-only and only
  the gateways reach them, the human alone launches the QA server and judges the look in a
  browser, and the owner commits unless the owner says otherwise.

## Status update

(2026-11-19 16:06:35)
Created at the owner's instruction, when TASK-001.07 was marked DONE. Status WIP. The work
starts with the assessment of sec-111 as it stands and of the level pair's design.
Remaining: the assessment, the integration plan, its review and the owner's reading of the
plan.
